
const firebaseConfig = {
  apiKey: "AIzaSyBYjz-8gLWQMlbs6PLQRLJDuSws5p3pqSE",
  authDomain: "imc-cordova.firebaseapp.com",
  projectId: "imc-cordova",
  storageBucket: "imc-cordova.appspot.com",
  messagingSenderId: "893375658732",
  appId: "1:893375658732:web:262f4877aa2df9728903c9",
  measurementId: "G-11GKKL7ZGV"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);