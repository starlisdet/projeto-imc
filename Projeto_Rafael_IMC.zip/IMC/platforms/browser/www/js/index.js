var imc = "null";

var box_imc = document.getElementById('imc-value');
var register_imc = document.getElementById('register-imc');

if (imc) {
    box_imc.append("19.19");
} else {
    register_imc.append("Gravar dados");
}
